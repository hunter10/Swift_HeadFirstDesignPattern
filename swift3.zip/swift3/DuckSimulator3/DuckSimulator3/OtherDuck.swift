//
//  OtherDuck.swift
//  DuckSimulator3
//
//  Created by junginsung on 2017. 3. 10..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class DuckCall : Quackable{
    var observable:Observable?
    
    init(){
        self.observable = Observable(duck: self)
    }

    func quack() {
        print("Kwak")
        notifyObservers()
    }
    
    func registerObserver(observer: Observer) {
        observable?.registerObserver(observer: observer)
    }
    
    func notifyObservers() {
        observable?.notifyObservers()
    }

}

class RubberDuck : Quackable{
    var observable:Observable?
    
    init(){
        self.observable = Observable(duck: self)
    }

    
    func quack() {
        print("Squeak")
        notifyObservers()
    }
    
    func registerObserver(observer: Observer) {
        observable?.registerObserver(observer: observer)
    }
    
    func notifyObservers() {
        observable?.notifyObservers()
    }

}
