//
//  AbstractDuckFactory.swift
//  DuckSimulator3
//
//  Created by junginsung on 2017. 3. 10..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

protocol AbstractDuckFactory{
    func createMallardDuck() -> Quackable
    func createRedheadDuck() -> Quackable
    func createDuckCall() -> Quackable
    func createRubberDuck() -> Quackable
}

class DuckFactory : AbstractDuckFactory{
    
    func createMallardDuck() -> Quackable {
        return MallardDuck()
    }
    
    func createRedheadDuck() -> Quackable {
        return RedheadDuck()
    }
    
    func createDuckCall() -> Quackable {
        return DuckCall()
    }
    
    func createRubberDuck() -> Quackable {
        return RubberDuck()
    }
}

class CountingDuckFactory : AbstractDuckFactory{
    
    func createMallardDuck() -> Quackable {
        return QuackCounter(duck: MallardDuck())
    }
    
    func createRedheadDuck() -> Quackable {
        return QuackCounter(duck: RedheadDuck())
    }
    
    func createDuckCall() -> Quackable {
        return QuackCounter(duck: DuckCall())
    }
    
    func createRubberDuck() -> Quackable {
        return QuackCounter(duck: RubberDuck())
    }
}
