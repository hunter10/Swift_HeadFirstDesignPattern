//
//  DuckSimulator.swift
//  DuckSimulator3
//
//  Created by junginsung on 2017. 3. 10..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class DuckSimulator{
    
    func simulate(duckFactory: AbstractDuckFactory) {
        //let mallardDuck:Quackable = duckFactory.createMallardDuck()
        let redHeadDuck:Quackable = duckFactory.createRedheadDuck()
        let duckCall:Quackable = duckFactory.createDuckCall()
        let rubberDuck:Quackable = duckFactory.createRubberDuck()
        let gooseDuck:Quackable = GooseAdapter(goose: Goose())
        
        print("---Duck Simulator---")
        
        let flockOfDucks = Flock()
        flockOfDucks.add(quacker: redHeadDuck)
        flockOfDucks.add(quacker: duckCall)
        flockOfDucks.add(quacker: rubberDuck)
        flockOfDucks.add(quacker: gooseDuck)
        
        let flockOfMallard = Flock()
        let mallardOne:Quackable = duckFactory.createMallardDuck()
        let mallardTwo:Quackable = duckFactory.createMallardDuck()
        let mallardThree:Quackable = duckFactory.createMallardDuck()
        let mallardFour:Quackable = duckFactory.createMallardDuck()
        flockOfMallard.add(quacker: mallardOne)
        flockOfMallard.add(quacker: mallardTwo)
        flockOfMallard.add(quacker: mallardThree)
        flockOfMallard.add(quacker: mallardFour)
        flockOfDucks.add(quacker: flockOfMallard)
        
        let quackologist:QuackoLogist = QuackoLogist()
        flockOfDucks.registerObserver(observer: quackologist)
        
        
        //simulate(duck: mallardDuck)
        //simulate(duck: redHeadDuck)
        //simulate(duck: duckCall)
        //simulate(duck: rubberDuck)
        //simulate(duck: gooseDuck)
        
        print("\nDuck Simulator : Whole Flock Simulator")
        simulate(duck:flockOfDucks)
        
        //print("\nDuck Simulator : Mallard Flock Simulator")
        //simulate(duck:flockOfMallard)
        
        print("The ducks quacked \(QuackCounter.getQuacks()) times")
        
    }

    func simulate() {
        let mallardDuck:Quackable = QuackCounter(duck: MallardDuck())
        let redHeadDuck:Quackable = QuackCounter(duck:RedheadDuck())
        let duckCall:Quackable = QuackCounter(duck:DuckCall())
        let rubberDuck:Quackable = QuackCounter(duck:RubberDuck())
        let gooseDuck:Quackable = GooseAdapter(goose: Goose())
        
        print("---Duck Simulator---")
        
        simulate(duck: mallardDuck)
        simulate(duck: redHeadDuck)
        simulate(duck: duckCall)
        simulate(duck: rubberDuck)
        simulate(duck: gooseDuck)
        
        print("The ducks quacked \(QuackCounter.getQuacks()) times")
        
    }
    
    func simulate(duck:Quackable){
        duck.quack()
    }
    
}
