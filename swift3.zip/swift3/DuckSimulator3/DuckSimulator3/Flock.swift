//
//  Flock.swift
//  DuckSimulator3
//
//  Created by junginsung on 2017. 3. 10..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class Flock : Quackable{
    
    var observable:Observable?
    var quacker:[Quackable] = []
    
    init(){
        self.observable = Observable(duck: self)
    }
    
    func add(quacker:Quackable){
        self.quacker.append(quacker)
    }
    
    func quack() {
        for item in quacker {
            item.quack()
        }
    }
    
    func registerObserver(observer: Observer) {
        //observable?.registerObserver(observer: observer)
        
        for item in quacker{
            item.registerObserver(observer: observer)
        }
    }
    
    func notifyObservers() {
        
    }
}
