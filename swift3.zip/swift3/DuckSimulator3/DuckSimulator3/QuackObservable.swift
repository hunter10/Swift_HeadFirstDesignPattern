//
//  QuackObservable.swift
//  DuckSimulator3
//
//  Created by junginsung on 2017. 3. 12..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

protocol Observer{ // interface
    func update(duck:QuackObservable)
}

class QuackoLogist : Observer{
    func update(duck: QuackObservable) {
        print("Quackologist \(type(of: (duck))) just quacked.")
        print()

        let lhs:String = "\(type(of:(duck)))"
        let rhs:String = "\(GooseAdapter.self)"
        if(lhs == rhs )
        {
            print("         거위다...")
        }

    }
}

protocol QuackObservable {
    func registerObserver(observer:Observer)
    func notifyObservers()
}

class Observable : QuackObservable{
    var observers:[Observer] = []
    var duck:QuackObservable?
    
    init(duck:QuackObservable){
        self.duck = duck
    }
    
    func registerObserver(observer: Observer) {
        self.observers.append(observer)
    }
    
    func notifyObservers() {
        for item in observers {
            item.update(duck: duck!)
        }
    }
}
