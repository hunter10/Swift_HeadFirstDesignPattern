//
//  Quackable.swift
//  DuckSimulator3
//
//  Created by junginsung on 2017. 3. 10..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

protocol Quackable : QuackObservable{
    func quack()
}

class QuackCounter : Quackable{
    var duck:Quackable
    static var numberOfQuacks:Int = 0
    
    init(duck:Quackable){
        self.duck = duck
    }
    
    func quack() {
        duck.quack()
        QuackCounter.numberOfQuacks += 1
    }
    
    static func getQuacks() -> Int{
        return numberOfQuacks
    }
    
    func registerObserver(observer: Observer) {
        duck.registerObserver(observer: observer)
    }
    
    func notifyObservers() {
        duck.notifyObservers()
    }
}
