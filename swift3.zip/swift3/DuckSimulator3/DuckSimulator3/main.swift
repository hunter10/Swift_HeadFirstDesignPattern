//
//  main.swift
//  DuckSimulator3
//
//  Created by junginsung on 2017. 3. 10..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

var duckSim:DuckSimulator = DuckSimulator()
//duckSim.simulate()

let duckFactory:AbstractDuckFactory = CountingDuckFactory()
duckSim.simulate(duckFactory: duckFactory)
