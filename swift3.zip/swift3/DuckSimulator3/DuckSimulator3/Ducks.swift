//
//  Ducks.swift
//  DuckSimulator3
//
//  Created by junginsung on 2017. 3. 10..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class MallardDuck : Quackable{
    var observable:Observable?
    
    init(){
        self.observable = Observable(duck: self)
    }
    
    func quack() {
        print("Quack")
        notifyObservers()
    }
    
    func registerObserver(observer: Observer) {
        observable?.registerObserver(observer: observer)
    }
    
    func notifyObservers() {
        observable?.notifyObservers()
    }
}

class RedheadDuck : Quackable{
    var observable:Observable?
    
    init(){
        self.observable = Observable(duck: self)
    }
    
    func quack() {
        print("Quack")
        notifyObservers()
    }
    
    func registerObserver(observer: Observer) {
        observable?.registerObserver(observer: observer)
    }
    
    func notifyObservers() {
        observable?.notifyObservers()
    }
}

class Goose {
    func honk() {
        print("Honk")
    }
}

class GooseAdapter : Quackable{
    var observable:Observable?
    
    var goose:Goose
    
    init(goose:Goose){
        self.goose = goose
        self.observable = Observable(duck: self)
    }
    
    func quack() {
        goose.honk()
        notifyObservers()
    }
    
    func registerObserver(observer: Observer) {
        observable?.registerObserver(observer: observer)
    }
    
    func notifyObservers() {
        observable?.notifyObservers()
    }
}
