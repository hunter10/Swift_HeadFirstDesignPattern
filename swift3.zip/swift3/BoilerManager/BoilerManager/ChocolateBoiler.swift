//
//  ChocolateBoiler.swift
//  BoilerManager
//
//  Created by junginsung on 2017. 2. 12..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class ChocolateBoiler{
    var empty:Bool
    var boiled:Bool
    
    static let sharedInstance = ChocolateBoiler()
    
    required public init(){
        self.empty = true
        self.boiled = false
    }
    
    func fill() {
        if(isEmpty()){
            empty = false
            boiled = false
        }
    }
    
    func drain(){
        if(!isEmpty() && isBoiled()){
            empty = true
        }
    }
    
    func boil(){
        if(!isEmpty() && !isBoiled()){
            boiled = true
        }
    }
    
    func isEmpty() -> Bool{
        return empty
    }
    
    func isBoiled() -> Bool{
        return boiled
    }
}
