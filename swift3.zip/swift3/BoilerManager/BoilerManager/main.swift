//
//  main.swift
//  BoilerManager
//
//  Created by junginsung on 2017. 2. 12..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

print("Hello, World!")

let boiler:ChocolateBoiler = ChocolateBoiler.sharedInstance
boiler.fill()
boiler.boil()
boiler.drain()
