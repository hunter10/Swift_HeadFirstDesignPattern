//
//  HeatIndexDisplay.swift
//  WeatherProject
//
//  Created by junginsung on 2017. 1. 15..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class HeatIndexDisplay : Observer, DisplayElemnet{
    
    var weatherData:WeatherData? = nil
    
    init(weatherData:WeatherData){
        super.init()
        self.weatherData = weatherData
        weatherData.registerObserver(o: self)
    }
    
    override func update(temperature: Float, humidity: Float, pressure: Float) {
        
        display()
    }
    
    func display() {
        print("옵져버 패턴은 이렇게 쓰는구나")
    }
}
