//
//  StatisticsDisplay.swift
//  WeatherProject
//
//  Created by junginsung on 2017. 1. 15..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class StatisticsDisplay : Observer, DisplayElemnet{
    var maxTemp:Float = 0.0
    var minTemp:Float = 200
    var tempSum:Float = 0.0
    var numReadings:Int = 0
    var weatherData:WeatherData? = nil
    
    
    
    init(weatherData:WeatherData){
        super.init()
        self.weatherData = weatherData
        weatherData.registerObserver(o: self)
    }
    
    override func update(temperature: Float, humidity: Float, pressure: Float) {
        tempSum += temperature
        numReadings += 1
        
        if(temperature > maxTemp){
            maxTemp = temperature
        }
        
        
        if(temperature < minTemp){
            minTemp = temperature
        }
        
        display()
    }
    
    func display(){
        let tempAvg = tempSum/Float(numReadings)
        print("Avg/Max/Min temperature =  \(tempAvg) / \(maxTemp) / \(minTemp)")
    }
}
