//
//  CurrentConditionsDisplay.swift
//  WeatherProject
//
//  Created by junginsung on 2017. 1. 15..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class CurrentConditionsDisplay : Observer, DisplayElemnet{
    
    var temperature:Float = 0.0
    var humidity:Float = 0.0
    var weatherData:Subject? = nil
    
    init(weatherData:Subject){
        super.init()
        self.weatherData = weatherData
        weatherData.registerObserver(o: self)
    }
    
    override func update(temperature: Float, humidity: Float, pressure: Float) {
        self.temperature = temperature
        self.humidity = humidity
        display()
    }
    
    func display(){
        print("Current conditions: \(temperature)F degrees and \(humidity)% humidity" )
    }
}
