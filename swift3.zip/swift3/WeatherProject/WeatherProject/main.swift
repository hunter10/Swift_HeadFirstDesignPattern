//
//  main.swift
//  WeatherProject
//
//  Created by junginsung on 2017. 1. 15..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

print("Hello, Weater Project!")
print("---")

class WeaterStation{
}

var testWeatherData:WeatherData = WeatherData()

var currentDisplay:CurrentConditionsDisplay = CurrentConditionsDisplay(weatherData: testWeatherData)
var statisticsDisplay:StatisticsDisplay = StatisticsDisplay(weatherData: testWeatherData)
var ForecastDispaly:ForecastDisplay = ForecastDisplay(weatherData: testWeatherData)
var heatIndexDisplay:HeatIndexDisplay = HeatIndexDisplay(weatherData: testWeatherData)

testWeatherData.setMeasurements(temperature: 80, humidity: 65, pressure: 30.4)
testWeatherData.setMeasurements(temperature: 82, humidity: 70, pressure: 29.2)
testWeatherData.setMeasurements(temperature: 78, humidity: 90, pressure: 29.2)
