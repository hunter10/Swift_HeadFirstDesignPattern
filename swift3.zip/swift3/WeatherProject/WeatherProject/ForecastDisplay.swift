//
//  ForecastDisplay.swift
//  WeatherProject
//
//  Created by junginsung on 2017. 1. 15..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class ForecastDisplay : Observer, DisplayElemnet{
    var currentPressure:Float = 29.92
    var lastPressure:Float = 0.0
    var weatherData:Subject? = nil
    
    init(weatherData:Subject){
        super.init()
        self.weatherData = weatherData
        weatherData.registerObserver(o: self)
    }
    
    override func update(temperature: Float, humidity: Float, pressure: Float) {
        lastPressure = currentPressure
        currentPressure = pressure
        
        display()
    }
    
    func display(){
        var result = "Forecast:"
        if(currentPressure > lastPressure){
            result += "Improving weather on the way!\n"
        }
        else if(currentPressure == lastPressure){
            result += "More of the same\n"
        }
        else if(currentPressure < lastPressure){
            result += "Watch out for cooler, rainy weather\n"
        }
        
        print(result)
    }
}
