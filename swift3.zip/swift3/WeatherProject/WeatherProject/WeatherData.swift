//
//  WeatherData.swift
//  WeatherProject
//
//  Created by junginsung on 2017. 1. 15..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class WeatherData : Subject{
    
    var observers:[Observer]
    var temperature:Float = 0.0
    var humidity:Float = 0.0
    var pressure:Float = 0.0
    
    override init(){
        observers = [Observer]()
    }
    
    override func registerObserver(o: Observer) {
        observers.append(o)
    }
    
    override func removeObserver(o: Observer) {
        //let index = observers.index(where:{$0 as! AnyHashable == o as! AnyHashable})
        let i = observers.index{$0 === o}
        if(i! >= 0){
            observers.remove(at: i!)
        }
    }
    
    override func notifyObserver() {
        for item in observers{
            item.update(temperature: Float(temperature), humidity: Float(humidity), pressure: Float(pressure))
        }
    }
    
    func measurementsChanged(){
        notifyObserver()
    }
    
    func setMeasurements(temperature:Float, humidity:Float, pressure:Float){
        self.temperature = temperature
        self.humidity = humidity
        self.pressure = pressure
        measurementsChanged()
    }
}
