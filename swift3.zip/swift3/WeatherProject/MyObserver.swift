//
//  MyObserver.swift
//  WeatherProject
//
//  Created by junginsung on 2017. 1. 15..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class Subject{ // interface
    func registerObserver(o:Observer) {}
    func removeObserver(o:Observer){}
    func notifyObserver(){}
}

class Observer{ // interface
    init(){}
    func update(temperature:Float, humidity:Float, pressure:Float){}
}

protocol DisplayElemnet { // interface
    func display()
}
