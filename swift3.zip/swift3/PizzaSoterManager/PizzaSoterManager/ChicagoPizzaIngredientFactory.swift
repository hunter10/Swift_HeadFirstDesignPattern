//
//  ChicagoPizzaIngredientFactory.swift
//  PizzaSoterManager
//
//  Created by junginsung on 2017. 1. 30..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class ChicagoPizzaIngredientFactory : PizzaIngredientFactory
{
    
    func createDough() -> Dough {
        return ThickCrustDough()
    }
    
    func createSauce() -> Sauce {
        return PlumTomatoSauce()
    }
    
    func createCheese() -> Cheese {
        return MozzarellaCheese()
    }
    
    func createVeggies() -> [Veggies] {
        let veggies:[Veggies] = [Garlic(), Onion(), Mushroom(), RedPepper()]
        return veggies
    }
    
    internal func createPepperoni() -> Pepperoni {
        return SlicedPepperoni()
    }

    
    func createClams() -> Clams {
        return FrozenClams()
    }
}

class ThickCrustDough : Dough{
    override init(){
        print("ThickCrushDough...")
    }
}

class PlumTomatoSauce : Sauce{
    override init(){
        print("PlumTomato Sauce...")
    }
}

class MozzarellaCheese : Cheese{
    
}

class FrozenClams : Clams{
    
}
