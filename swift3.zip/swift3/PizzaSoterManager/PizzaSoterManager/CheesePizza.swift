//
//  CheesePizza.swift
//  PizzaSoterManager
//
//  Created by junginsung on 2017. 1. 30..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class CheesePizza : Pizza{
    var ingredientFactory:PizzaIngredientFactory
    
    init(ingredientFactory:PizzaIngredientFactory){
        self.ingredientFactory = ingredientFactory
    }
    
    override func prepare() {
        print("Preparing...\(getName())")
        dough = ingredientFactory.createDough()
        sauce = ingredientFactory.createSauce()
    }
}
