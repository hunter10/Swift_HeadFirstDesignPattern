//
//  Pizza.swift
//  PizzaSoterManager
//
//  Created by junginsung on 2017. 1. 29..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

// 제품 클래스


protocol PizzaPrepare {
    func prepare()
}

// 추상클래스
class Pizza : PizzaPrepare{
    private var name:String = ""
    var dough:Dough = Dough()
    var sauce:Sauce = Sauce()
    var toppings:[String] = [String]()
    
    
    func prepare() {
        
    }
    
    //func prepare(){
    //    print("Preparing \(name) ...")
    //    print("Tossing dough...")
    //    print("Adding sauce...")
    //    print("Adding toppings: ")
        
    //    for obj in toppings{
    //        print("  \(obj)")
    //    }
    //}
    
    func bake(){
        print("Bake for 25 minutes at 350")
    }
    
    func cut(){
        print("Cutting the pizza into diagonal slices")
    }
    
    func box(){
        print("Place pizza in officail PizzaStore Box...")
    }
    
    func getName()->String{
        return name
    }
    
    func setName(name:String){
        self.name = name
    }
}
