//
//  PizzaStore.swift
//  PizzaSoterManager
//
//  Created by junginsung on 2017. 1. 29..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

// 생산자 클래스

// 꼭 구현해야 하는 추상 메소드 정의
protocol PizzaStoreProtocol{
    func createPizza(type:String) -> Pizza
}

// 추상클래스
class PizzaStore : PizzaStoreProtocol{
    var pizza:Pizza?
    
    func createPizza(type: String) -> Pizza {
        return pizza!
    }
    
    func orderPizza(type:String)->Pizza{
        var pizza:Pizza? = nil
        
        pizza = createPizza(type: type)
        
        pizza?.prepare()
        pizza?.bake()
        pizza?.cut()
        pizza?.box()
        return pizza!
    }
}
