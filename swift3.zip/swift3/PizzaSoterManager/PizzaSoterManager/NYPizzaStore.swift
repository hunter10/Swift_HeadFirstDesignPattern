//
//  NYPizzaStore.swift
//  PizzaSoterManager
//
//  Created by junginsung on 2017. 1. 29..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class NYPizzaStore : PizzaStore{
    
    override func createPizza(type: String) -> Pizza {
        var pizza:Pizza? = nil
        var ingredientFactory:PizzaIngredientFactory = NYPizzaIngredientFactory()
        
        if(type == "cheese"){
            //pizza = NYStyleCheesePizza(name: "NYStyleCheesePizza")
            
            pizza = CheesePizza(ingredientFactory: ingredientFactory)
            pizza?.setName(name: "New York Style Cheese Pizza")
        }
        else if(type == "veggie"){
            //pizza = NYStyleVeggiePizza(name: "NYStyeVeggiePizza")
        }
        else if(type == "clam"){
            //pizza = NYStyleClamPizza(name: "NYStyeClamPizza")
        }
        else if(type == "pepperoni"){
            //pizza = NYStylePepperoniPizza(name: "NYStyePepperoniPizza")
        }
        
        return pizza!
    }
}

//class NYStyleCheesePizza : Pizza {
//    override init(name:String){
        //super.init(name: name)
        //name = "NY Styel Sauce and Cheese Pizze"
        //super.init(name: "NY Styel Sauce and Cheese Pizze")
        //dough = "Thin Crust Dough"
        //sauce = "Marinara Sauce"
        
        //toppings.append("Grated Reggiano Cheese")
//    }
//}

class NYStyleVeggiePizza : Pizza {
    //override init(name:String){
    //    super.init(name: name)
    //}
}

class NYStyleClamPizza : Pizza {
    //override init(name:String){
    //    super.init(name: name)
   // }
}

class NYStylePepperoniPizza : Pizza {
    //override init(name:String){
    //    super.init(name: name)
    //}
}
