//
//  NYPizzaIngredientFactory.swift
//  PizzaSoterManager
//
//  Created by junginsung on 2017. 1. 30..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class NYPizzaIngredientFactory : PizzaIngredientFactory
{
    internal func createPepperoni() -> Pepperoni {
        return SlicedPepperoni()
    }
    
    func createDough() -> Dough {
        return ThinCrustDough()
    }
    
    func createSauce() -> Sauce {
        return MarinaraSauce()
    }
    
    func createCheese() -> Cheese {
        return ReggianoCheese()
    }
    
    func createVeggies() -> [Veggies] {
        let veggies:[Veggies] = [Garlic(), Onion(), Mushroom(), RedPepper()]
        return veggies
    }
    
    func createClams() -> Clams {
        return FreshClams()
    }
}

class ThinCrustDough : Dough {
    override init(){
        print("ThinCrushtDough...")
    }
}

class MarinaraSauce : Sauce{
    override init(){
        print("MarinaraSauce...")
    }
}

class ReggianoCheese : Cheese{
    
}

class Garlic : Veggies{
    
}

class Onion : Veggies{
    
}

class Mushroom : Veggies{
    
}

class RedPepper : Veggies{
    
}

class SlicedPepperoni : Pepperoni{
    
}

class FreshClams : Clams{
    
}
