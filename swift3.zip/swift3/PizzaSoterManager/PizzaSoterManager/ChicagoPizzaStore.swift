//
//  ChicagoPizzaStore.swift
//  PizzaSoterManager
//
//  Created by junginsung on 2017. 1. 29..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class ChicagoPizzaStore : PizzaStore{
    override func createPizza(type: String) -> Pizza {
        var pizza:Pizza? = nil
        var ingredientFactory:PizzaIngredientFactory = ChicagoPizzaIngredientFactory()
        
        
        if(type == "cheese"){
            //pizza = ChicagoStyleCheesePizza(name: "CHStyleCheesePizza")
            
            pizza = CheesePizza(ingredientFactory: ingredientFactory)
            pizza?.setName(name: "Chicago Style Cheese Pizza")
        }
        else if(type == "veggie"){
            //pizza = ChicagotyleVeggiePizza(name: "CHStyeVeggiePizza")
        }
        else if(type == "clam"){
            //pizza = ChicagoStyleClamPizza(name: "CHStyeClamPizza")
        }
        else if(type == "pepperoni"){
            //pizza = ChicagoStylePepperoniPizza(name: "CHStyePepperoniPizza")
        }
        
        return pizza!
    }
}

/*
class ChicagoStyleCheesePizza : Pizza {
    override init(name:String){
        super.init(name: "Chicago Style Deep Dish Cheese Pizza")
        dough = "Extra Thick Crust Dough"
        sauce = "Plum Tomato Sauce"
        
        toppings.append("Shredded Mozzarella Cheese")
    }
    
    override func cut() {
        print("Cutting the pizza into square slices")
    }
}
*/

class ChicagotyleVeggiePizza : Pizza {
    //override init(name:String){
      //  super.init(name: name)
    //}
}

class ChicagoStyleClamPizza : Pizza {
    //override init(name:String){
    //    super.init(name: name)
    //}
}

class ChicagoStylePepperoniPizza : Pizza {
    //override init(name:String){
    //    super.init(name: name)
    //}
}
