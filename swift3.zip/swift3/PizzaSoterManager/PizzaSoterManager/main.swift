//
//  main.swift
//  PizzaSoterManager
//
//  Created by junginsung on 2017. 1. 29..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

print("Hello, World!")

var chStore:ChicagoPizzaStore = ChicagoPizzaStore()
var pizza:Pizza = chStore.orderPizza(type: "cheese")
print("Ethan ordered a \(pizza.getName())")

print("---")

var nyStore:NYPizzaStore = NYPizzaStore()
pizza = nyStore.orderPizza(type: "cheese")
print("Joel ordered a \(pizza.getName())" )
//print("---")
//nyStore.orderPizza(type: "pepperoni")
