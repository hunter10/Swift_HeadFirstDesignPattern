//
//  PizzaIngredientFactory.swift
//  PizzaSoterManager
//
//  Created by junginsung on 2017. 1. 30..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

protocol PizzaIngredientFactory{
    func createDough() -> Dough
    func createSauce() -> Sauce
    func createCheese() -> Cheese
    func createVeggies() -> [Veggies]
    func createPepperoni() -> Pepperoni
    func createClams() -> Clams
}

class Dough{
    
}

class Sauce{
    
}

class Cheese{
    
}

class Veggies{
    
}

class Pepperoni{
    
}

class Clams{
    
}
