//
//  FlyNoWay.swift
//  DuckSimulator
//
//  Created by junginsung on 2017. 1. 8..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class FlyNoWay : FlyBehavior
{
    override func fly() {
        print("Not fly...")
    }
}
