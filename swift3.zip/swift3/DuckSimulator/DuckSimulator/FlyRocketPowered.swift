//
//  FlyRocketPowered.swift
//  DuckSimulator
//
//  Created by junginsung on 2017. 1. 8..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation
class FlyRocketPowered : FlyBehavior
{
    override func fly() {
        print("로켓추진으로 날아갑니다.")
    }
}
