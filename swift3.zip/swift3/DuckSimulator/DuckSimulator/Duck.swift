//
//  Duck.swift
//  DuckSimulator
//
//  Created by junginsung on 2017. 1. 8..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class Duck
{
    var quackBehavior:QuackBehavior = QuackBehavior()
    var flyBehavior:FlyBehavior = FlyBehavior()
    
    func swim(){}
    func display(){}
    
    func performFly() {
        flyBehavior.fly()
    }
    
    func performQuack(){
        quackBehavior.quack()
    }
    
    func setFlyBehavior(fb:FlyBehavior) {
        flyBehavior = fb
    }
    
    func setQuackBehavior(qb:QuackBehavior) {
        quackBehavior = qb
    }
}
