//
//  RedheadDuck.swift
//  DuckSimulator
//
//  Created by junginsung on 2017. 1. 8..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation
class RedheadDuck : Duck
{
    override init()
    {
        super.init()
        flyBehavior = FlyWithWings()
        quackBehavior = Quack()
    }
    
    override func swim() {
        print("Redhead Duck swim!")
    }
    
    override func display() {
        print("Redhead Duck display!")
    }
}
