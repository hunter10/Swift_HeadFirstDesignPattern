//
//  ModelDuck.swift
//  DuckSimulator
//
//  Created by junginsung on 2017. 1. 8..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation
class ModelDuck : Duck
{
    override init(){
        super.init()
        flyBehavior = FlyNoWay()
        quackBehavior = Quack()
        
    }
    
    override func display() {
        print("저는 모형 오리 입니다.")
    }
}
