//
//  RubberDuck.swift
//  DuckSimulator
//
//  Created by junginsung on 2017. 1. 8..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class RubberDuck : Duck
{
    override init()
    {
        super.init()
        self.flyBehavior = FlyNoWay()
        self.quackBehavior = Squeak()
    }

    
    override func swim() {
        print("Rubber Duck swim!")
    }
    
    override func display() {
        print("Rubber Duck display!")
    }
}
