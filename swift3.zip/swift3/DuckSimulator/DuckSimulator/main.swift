//
//  main.swift
//  DuckSimulator
//
//  Created by junginsung on 2017. 1. 8..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

let M_Duck = MallardDuck()
M_Duck.display()
M_Duck.performQuack()
M_Duck.swim()
M_Duck.performFly()
print("---")

let R_Duck = RedheadDuck()
R_Duck.display()
R_Duck.performQuack()
R_Duck.swim()
M_Duck.performFly()
print("---")

let Ru_Duck = RubberDuck()
Ru_Duck.display()
Ru_Duck.performQuack()
Ru_Duck.swim()
Ru_Duck.performFly()
print("---")

let Mo_Duck = ModelDuck()
Mo_Duck.display()
Mo_Duck.performQuack()
Mo_Duck.performFly()
Mo_Duck.setFlyBehavior(fb: FlyRocketPowered())
Mo_Duck.performFly()
print("---")
