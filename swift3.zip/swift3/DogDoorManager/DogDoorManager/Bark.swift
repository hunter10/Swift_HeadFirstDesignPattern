//
//  Bark.swift
//  DogDoorManager
//
//  Created by junginsung on 2016. 9. 25..
//  Copyright © 2016년 junginsung. All rights reserved.
//

import Foundation

class Bark{
    var sound:String = ""
    
    init(_ sound:String){
        self.sound = sound
    }
    
    func getSound() -> String {
        return sound
    }
    
    func equals(_ bark:AnyObject) -> Bool {
        let otherBark = bark as! Bark
        
        if self.sound == otherBark.sound {
            return true
        }
        
        return false
    }
}
