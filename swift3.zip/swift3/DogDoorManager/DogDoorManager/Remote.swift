//
//  Remote.swift
//  DogDoorManager
//
//  Created by junginsung on 2016. 9. 18..
//  Copyright © 2016년 junginsung. All rights reserved.
//

import Foundation


class Remote {
    var door = DogDoor()
    
    
    init(_ door:DogDoor){
        setDoor(door)
    }
    
    func setDoor(_ door:DogDoor){
        self.door = door
    }
    
    func pressButton() {
        print("Pressing the remote control button...")
        
        if door.IsOepn() {
            door.Close()
        } else {
            door.Open()
        }
    }
}
