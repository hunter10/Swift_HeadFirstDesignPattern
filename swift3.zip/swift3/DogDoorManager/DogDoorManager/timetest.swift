//
//  timetest.swift
//  DogDoorManager
//
//  Created by junginsung on 2016. 9. 18..
//  Copyright © 2016년 junginsung. All rights reserved.
//

import Foundation

class SimpleTimerTest
{
    var mytimer : Timer?
    
    func someTask( timeout:TimeInterval )
    {
        mytimer = Timer.scheduledTimer(timeInterval: timeout,
                                       target: self,
                                       selector: #selector(updateCounter),
                                       userInfo: nil,
                                       repeats: true)
    }

    
    @objc func updateCounter() {
        print("a")
        //mytimer?.invalidate()
        //mytimer = nil
        //print("kill")
    }
}
