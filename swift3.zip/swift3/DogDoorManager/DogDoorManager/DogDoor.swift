//
//  DogDoor.swift
//  DogDoorManager
//
//  Created by junginsung on 2016. 9. 18..
//  Copyright © 2016년 junginsung. All rights reserved.
//

import Foundation

class DogDoor{
    var open:Bool = false
    var mytimer:Timer?
    var allowedBark = [Bark]()
    
    init() {
        open = false
        //allowedBark = Bark("")
    }
    
    func Open() {
        print("\nThe dog door opens.")
        open = true
        
        runTimer(timeout: 2.0)
    }
    
    func Close() {
        print("\nThe dog door close.")
        open = false
    }
    
    func IsOepn() -> Bool {
        return open
    }

    func addAllowedBark(_ bark:Bark){
        allowedBark += [bark]
    }
    
    func getAllowedBarks() -> [Bark]?{
        //var matchBarks = [Bark]()
        //return matchBarks
        
        return allowedBark
    }
    
//    func setAllowedBark(_ bark:Bark){
//        allowedBark = bark
//    }
    
//    func getAllowedBark() -> Bark{
//        return allowedBark
//    }
    
    func runTimer( timeout:TimeInterval )
    {
        mytimer = Timer.scheduledTimer(timeInterval: timeout,
                                       target: self,
                                       selector: #selector(UpdateTimer),
                                       userInfo: nil,
                                       repeats: false)
    }
    
    @objc func UpdateTimer(){
        Close()
    }
}
