//
//  BarkRecognizer.swift
//  DogDoorManager
//
//  Created by junginsung on 2016. 9. 18..
//  Copyright © 2016년 junginsung. All rights reserved.
//

import Foundation

class BarkRecognizer{
    
    var door : DogDoor?
    
    init(_ door:DogDoor){
        self.door = door
    }
    
    /*
    func recognizer(_ bark:String) {
        print("     BarkRecognizer: Heard a '" + bark + "'")
        door?.Open()
    }
    */
    
    func recognizer(_ bark:Bark){
        print("     BarkRecognizer: Heard a '" + bark.getSound() + "'")
       
        for listBark in (door?.getAllowedBarks())!{
            if listBark.equals(bark) {
                door?.Open()
                return
            }
        }
        
        print("This dog is not allowed")
        
//        if(door?.getAllowedBark().equals(bark))!{
//            door?.Open()
//        } else {
//            print("This dog is not allowed")
//        }
        
    }
    
} 
