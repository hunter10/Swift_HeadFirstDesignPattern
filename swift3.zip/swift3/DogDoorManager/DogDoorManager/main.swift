//
//  main.swift
//  DogDoorManager
//
//  Created by junginsung on 2016. 9. 18..
//  Copyright © 2016년 junginsung. All rights reserved.
//

import Foundation

class DogDoorSimulator{

    var mainTimer : Timer?
    
    var currTime = 0.0
    let endTime = 5.0
    
    var door : DogDoor?
    var remote : Remote?
    var recognizer : BarkRecognizer?
    
    func Start(){
        
        door = DogDoor()
        door?.addAllowedBark(Bark("yip"))
        door?.addAllowedBark(Bark("yyip"))
        //door?.setAllowedBark(Bark("yip"))
        
        remote = Remote(door!)
        recognizer = BarkRecognizer(door!)
        
        
        //print("Fido barks to go outside....")
        //remote!.pressButton()
        
        print("Fido starts barking.")
        recognizer?.recognizer(Bark("yyip"))
        
        
        if(door?.IsOepn() == false) { return }
            
        print("\nFido has gone outside....")
        print("\nFido's all done")
        
        runTimer(timeout: 0.1)
        
        //print("\nFido's back inside...")
        
        
        
        //var stimer = SimpleTimerTest()
        //stimer.someTask(timeout: 1)
    }
    
    func runTimer( timeout:TimeInterval )
    {
        mainTimer = Timer.scheduledTimer(timeInterval: timeout,
                                         target: self,
                                         selector: #selector(UpdateTimer),
                                         userInfo: nil,
                                         repeats: true)
    }
    
    @objc func UpdateTimer(){
        //print(currTime)
        currTime += 0.1
        
        if(currTime >= endTime)
        {
            mainTimer?.invalidate()
            
            print("\n...but he's stuck outside!")
            
            //print("\nFido start barking...")
            //print("\n...so Gina grabs the remote control.")
            //remote!.pressButton()
            
            print("Fido starts barking.")
            recognizer?.recognizer(Bark("yip"))
            
            print("\nFido's back inside...")
        }
    }
}

var main = DogDoorSimulator()
main.Start()
RunLoop.current.run()

