//
//  ViewController.swift
//  FlightBooking
//
//  Created by junginsung on 2016. 9. 18..
//  Copyright © 2016년 junginsung. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var selectDatePicker: UIDatePicker!
    
    @IBOutlet var departureDateButton: UIButton!
    
    @IBOutlet var returnDateLabel: UILabel!
    @IBOutlet var returnDateButton: UIButton!
    
    @IBAction func showRetureDateAction(_ sender: AnyObject) {
        print(sender.description!)
        
        returnDateLabel.isHidden = !(sender as! UISwitch).isOn
        returnDateButton.isHidden = !(sender as! UISwitch).isOn
    }
    
    var buttonTag:Int = 1
    @IBAction func showDatePickerAction(_ sender: AnyObject) {
        
        print(sender.description!)
        
        if selectDatePicker.isHidden == false{
            selectDatePicker.isHidden = true
        }else{
            selectDatePicker.isHidden = false
        }
        
        buttonTag = (sender as! UIButton).tag
    }
    
    
    @IBAction func selectedDateAction(_ sender: AnyObject) {
        let formatter = DateFormatter()
        formatter.dateFormat  = "YY-MM-d hh:mma"
        
        //let dateString = formatter.string(from: selectDatePicker.date)
        let dateString = formatter.string(from: (sender as! UIDatePicker).date)
        
        if buttonTag == 1 {
            departureDateButton.setTitle(dateString, for: UIControlState())
        }else{
            returnDateButton.setTitle(dateString, for: UIControlState())
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        returnDateLabel.isHidden = true;
        returnDateButton.isHidden = true;
        selectDatePicker.isHidden = true;
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
        selectDatePicker.isHidden = true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

