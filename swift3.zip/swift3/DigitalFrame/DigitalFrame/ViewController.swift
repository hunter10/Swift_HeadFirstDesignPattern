//
//  ViewController.swift
//  DigitalFrame
//
//  Created by junginsung on 2016. 8. 29..
//  Copyright © 2016년 junginsung. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var imgView:UIImageView!
    @IBOutlet var toggleButton:UIButton!
    @IBOutlet var speedSlider:UISlider!
    @IBOutlet var SpeedLabel:UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let cuteImages = [UIImage(named:"1.jpeg")!,
                          UIImage(named:"2.jpeg")!,
                          UIImage(named:"3.jpeg")!,
                          UIImage(named:"4.jpeg")!,
                          UIImage(named:"5.jpeg")!]
        
        imgView.animationImages = cuteImages
        imgView.animationDuration = 5.0
    }
    
    @IBAction func toggleAction(_ sender:AnyObject){
        
        if imgView.isAnimating{
            imgView.stopAnimating()
            toggleButton.setTitle("Start", for: UIControlState.normal)
        }else{
            imgView.startAnimating()
            toggleButton.setTitle("Stop", for: UIControlState.normal)
        }
    }

    @IBAction func changeSpeedAnction(_ sender:AnyObject){
        imgView.animationDuration = Double(speedSlider.value)
        imgView.startAnimating()
        toggleButton.setTitle("Stop", for: UIControlState.normal)
        SpeedLabel.text = "\(speedSlider.value)"
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

