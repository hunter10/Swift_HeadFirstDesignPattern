//
//  HasQuarterState.swift
//  GumballMachine
//
//  Created by junginsung on 2017. 3. 5..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class HasQuarterState : State{
    //  Make a variable equal to a random number....
    let randomNum:UInt32 = 0
    var gumballMachine:GumballMachine?
    
    func Rand(_ range: Range<Int>) -> Int {
        let distance = UInt32(range.upperBound - range.lowerBound)
        return range.lowerBound + Int(arc4random_uniform(distance + 1))
    }
    
    init(gumballMachine:GumballMachine){
        self.gumballMachine = gumballMachine
    }
    
    override func insertQuarter() {
        print("동전은 한 개만 넣어주세요")
    }
    
    override func ejectQuarter() {
        print("동전이 반환됩니다.")
        gumballMachine?.setState(state: (gumballMachine?.getNoQuarterState())!)
    }
    
    override func turnCrank() {
        print("손잡이를 돌리셨습니다.")
        let winner = Rand(0..<100)
        
        print("winner \(winner) getCount \((gumballMachine?.getCount())!)")
        
        if((winner < 10) && ((gumballMachine?.getCount())! > 1)){
            
            gumballMachine?.setState(state: (gumballMachine?.getWinnerState())!)
        } else {
            
            gumballMachine?.setState(state: (gumballMachine?.getSoldState())!)
        }
    }
    
    override func dispense() {
        print("알맹이가 나갈 수 없습니다.")
    }
}
