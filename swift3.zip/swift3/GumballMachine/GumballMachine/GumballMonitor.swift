//
//  GumballMonitor.swift
//  GumballMachine
//
//  Created by junginsung on 2017. 3. 10..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class GumballMonitor {
    var machine:GumballMachine?
    
    init(machine:GumballMachine){
        self.machine = machine
    }
    
    func report(){
        print("뽑기 기계 위치 : \(machine?.getLocation())")
        print("현재 재고 : \(machine?.getCount())")
        print("현재 상태 : \(machine?.printState())")
    }
}
