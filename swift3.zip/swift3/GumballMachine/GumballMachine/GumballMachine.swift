//
//  GumballMachine.swift
//  GumballMachine
//
//  Created by junginsung on 2017. 3. 4..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class GumballMachine{
    //static var SOLD_OUT:Int = 0         // 알맹이 매진
    //static var NO_QUARTER:Int = 1       // 동전 없음
    //static var HAS_QUARTER:Int = 2      // 동전 있음
    //static var SOLD:Int = 3             // 알맹이 판매
    
    //var state:Int = SOLD_OUT
    
    var soldOutState:State? = nil
    var noQuarterState:State? = nil
    var hasQuarterState:State? = nil
    var soldState:State? = nil
    var winnerState:State? = nil
    
    var state:State? //= soldOutState
    
    var count:Int = 0
    
    var location:String = ""
    
    //init(count:Int){
    //    self.count = count
    //    if(count > 0){
    //        state = GumballMachine.NO_QUARTER // 동전 없음
    //    }
    //}
    
    init(location:String, numberGumballs:Int){
        soldOutState = SoldOutState(gumballMachine: self)
        noQuarterState = NoQuarterState(gumballMachine: self)
        hasQuarterState = HasQuarterState(gumballMachine: self)
        soldState = SoldState(gumballMachine: self)
        winnerState = WinnerState(gumballMachine: self)
        
        self.count = numberGumballs
        if(numberGumballs > 0){
            state = noQuarterState
        }
        
        self.location = location
    }
    
    func getLocation() -> String{
        return location
    }
    
    func getCount() -> Int{
        return count
    }
    
    func refill(count:Int){
        self.count = count
        state = noQuarterState
    }
    
    func printState(){
        print("\n자바로 돌아가는 2004년형 뽑기 기계")
        print("남은 갯수 \(count) 현재상태 \(state!)")
        
        /*
        //if(state == GumballMachine.HAS_QUARTER){
            //print("동전은 한 개만 넣어주세요")
        } else if (state == GumballMachine.NO_QUARTER){
            print("동전 투입 대기중\n")
        } else if (state == GumballMachine.SOLD_OUT){
            print("매진")
        } else if (state == GumballMachine.SOLD) {
            //print("잠깐만 기다려 주세요. 알맹이가 나가고 있습니다.")
        }
        */
        
        if(state === hasQuarterState){
            
        } else if(state === noQuarterState){
            print("동전 투입 대기중\n")
        } else if(state === soldOutState){
            
        } else if(state === soldState){
            
        }
    }
    
    // 동전이 투입된 경우
    func insertQuarter(){
        /*
        if(state == GumballMachine.HAS_QUARTER){
            print("동전은 한 개만 넣어주세요")
        } else if (state == GumballMachine.NO_QUARTER){
            state = GumballMachine.HAS_QUARTER
            print("동전을 넣으셨습니다.")
        } else if (state == GumballMachine.SOLD_OUT){
            print("매진되었습니다. 다음 기회에 이용해주세요.")
        } else if (state == GumballMachine.SOLD) {
            print("잠깐만 기다려 주세요. 알맹이가 나가고 있습니다.")
        }
        */
        
        state?.insertQuarter()
    }
    
    // 사용자가 동전을 반환 받으려고 하는 경우
    func ejectQuarter(){
        /*
        if(state == GumballMachine.HAS_QUARTER){
            state = GumballMachine.NO_QUARTER
            print("동전이 반환됩니다.")
        } else if (state == GumballMachine.NO_QUARTER){
            print("동전을 넣어주세요.")
        } else if (state == GumballMachine.SOLD_OUT){
            print("동전을 넣지 않으셨습니다. 동전이 반환되지 않습니다.")
        } else if (state == GumballMachine.SOLD) {
            print("이미 알맹이를 뽑으셨습니다.")
        }
        */
        
        state?.ejectQuarter()
    }
    
    // 손잡이를 돌리는 경우
    func turnCrank(){
        
        /*
        if(state == GumballMachine.HAS_QUARTER){
            print("손잡이를 돌리셨습니다.")
            state = GumballMachine.SOLD
            dispense()
        } else if (state == GumballMachine.NO_QUARTER){
            print("동전을 넣어주세요.")
        } else if (state == GumballMachine.SOLD_OUT){
            print("매진되었습니다.")
        } else if (state == GumballMachine.SOLD) {
            print("손잡이는 한 번만 돌려주세요.")
        }
        */
        
        state?.turnCrank()
        state?.dispense()
    }
    
    func setState(state:State){
        self.state = state
    }
    
    func releaseBall(){
        print("알맹이가 슬롯에서 굴러나오는 중...")
        if(count != 0){
            count  = count - 1
        }
    }
    
    func getHasQuarterState() -> State{
        return hasQuarterState!
    }
    
    func getNoQuarterState() -> State{
        return noQuarterState!
    }
    
    func getSoldState() -> State{
        return soldState!
    }
    
    func  getSoldOutState() -> State {
        return soldOutState!
    }
    
    func getWinnerState() -> State {
        return winnerState!
    }
    
    /*
    // 알맹이 꺼내기
    func dispense(){
        if(state == GumballMachine.HAS_QUARTER){
            print("알맹이가 나갈 수 없습니다.")
        } else if (state == GumballMachine.NO_QUARTER){
            print("동전을 넣어주세요.")
        } else if (state == GumballMachine.SOLD_OUT){
            print("매진입니다.")
        } else if (state == GumballMachine.SOLD) {
            print("알맹이가 나가고 있습니다.")
            
            count = count - 1
            if(count == 0){
                print("더 이상 알맹이가 없습니다.")
                state = GumballMachine.SOLD_OUT
            } else {
                state = GumballMachine.NO_QUARTER
            }
            
        }
    }
    */
    
}
