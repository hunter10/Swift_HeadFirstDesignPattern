//
//  WinnerState.swift
//  GumballMachine
//
//  Created by junginsung on 2017. 3. 5..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation
class WinnerState : State{
    var gumballMachine:GumballMachine?
    
    init(gumballMachine:GumballMachine){
        self.gumballMachine = gumballMachine
    }
    
    override func insertQuarter() {
        print("잠깐만 기다려 주세요. 알맹이가 나가고 있습니다.")
    }
    
    override func ejectQuarter() {
        print("이미 알맹이를 뽑으셨습니다.")
    }
    
    override func turnCrank() {
        print("손잡이는 한 번만 돌려주세요.")
    }
    
    override func dispense() {
        
        print("축하드립니다.! 알맹이를 하나 더 받으실 수 있습니다.")
        gumballMachine?.releaseBall()
        
        if(gumballMachine?.getCount() == 0){
            gumballMachine?.setState(state: (gumballMachine?.getSoldOutState())!)
        } else {
            gumballMachine?.releaseBall()
            if((gumballMachine?.getCount())! > 0){
                gumballMachine?.setState(state: (gumballMachine?.getNoQuarterState())!)
            } else {
                print("더 이상 알맹이가 없습니다.")
                gumballMachine?.setState(state: (gumballMachine?.getSoldOutState())!)
            }
        }
    }
    
}
