//
//  State.swift
//  GumballMachine
//
//  Created by junginsung on 2017. 3. 4..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class State{
    func insertQuarter(){}
    func ejectQuarter(){}
    func turnCrank(){}
    func dispense(){}
}
