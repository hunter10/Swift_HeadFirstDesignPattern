//
//  NoQuarterState.swift
//  GumballMachine
//
//  Created by junginsung on 2017. 3. 4..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class NoQuarterState : State{
    var gumballMachine:GumballMachine?
    
    init(gumballMachine:GumballMachine){
        self.gumballMachine = gumballMachine
    }
    
    override func insertQuarter() {
        print("동전을 넣으셨습니다.")
        gumballMachine?.setState(state: (gumballMachine?.getHasQuarterState())!)
    }
    
    override func ejectQuarter() {
        print("동전을 넣어주세요")
    }
    
    override func turnCrank() {
        print("동전을 넣어주세요")
    }
    
    override func dispense() {
        print("동전을 넣어주세요")
    }
}
