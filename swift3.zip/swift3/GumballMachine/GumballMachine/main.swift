//
//  main.swift
//  GumballMachine
//
//  Created by junginsung on 2017. 3. 4..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation


//var gumballMachine = GumballMachine(count: 5)
//var gumballMachine = GumballMachine(numberGumballs: 5)
var gumballMachine = GumballMachine(location: "Guro", numberGumballs: 5)


/*
gumballMachine.printState()

gumballMachine.insertQuarter()
gumballMachine.turnCrank()

gumballMachine.printState()

gumballMachine.insertQuarter()
gumballMachine.ejectQuarter()
gumballMachine.turnCrank()

gumballMachine.printState()

gumballMachine.insertQuarter()
gumballMachine.turnCrank()
gumballMachine.insertQuarter()
gumballMachine.turnCrank()
gumballMachine.ejectQuarter()

gumballMachine.printState()

gumballMachine.insertQuarter()
gumballMachine.insertQuarter()
gumballMachine.turnCrank()
gumballMachine.insertQuarter()
gumballMachine.turnCrank()
gumballMachine.insertQuarter()
gumballMachine.turnCrank()

gumballMachine.printState()
*/






/*
gumballMachine.printState()

gumballMachine.insertQuarter()
gumballMachine.turnCrank()

gumballMachine.printState()


gumballMachine.insertQuarter()
gumballMachine.turnCrank()

gumballMachine.printState()

gumballMachine.insertQuarter()
gumballMachine.turnCrank()

gumballMachine.printState()

gumballMachine.insertQuarter()
gumballMachine.turnCrank()

gumballMachine.printState()

gumballMachine.insertQuarter()
gumballMachine.turnCrank()

gumballMachine.printState()

gumballMachine.insertQuarter()
gumballMachine.turnCrank()

gumballMachine.printState()
*/

var monitor = GumballMonitor(machine: gumballMachine)
monitor.report()
 
