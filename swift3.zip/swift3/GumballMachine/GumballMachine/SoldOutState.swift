//
//  SoldOutState.swift
//  GumballMachine
//
//  Created by junginsung on 2017. 3. 5..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class SoldOutState : State{
    var gumballMachine:GumballMachine?
    
    init(gumballMachine:GumballMachine){
        self.gumballMachine = gumballMachine
    }
    
    override func insertQuarter() {
        print("죄송합니다.매진되었습니다. insertQuarter" )
    }
    
    override func ejectQuarter() {
        print("죄송합니다.매진되었습니다. ejectQuarter")
    }
    
    override func turnCrank() {
        print("죄송합니다.매진되었습니다. turnCrank")
    }
    
    override func dispense() {
        print("알맹이가 나갈 수 없습니다. dispense")
    }
    
}
