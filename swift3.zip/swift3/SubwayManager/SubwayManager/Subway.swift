//
//  Subway.swift
//  SubwayManager
//
//  Created by junginsung on 2017. 1. 2..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class Subway{
    var stations:[Station]
    var connections = [Connection]()
    
    init(){
        stations = [Station]()
    }
    
    func addStation(stationName:String) {
        if(!hasStation(stationName: stationName)){
            let station:Station = Station(name: stationName)
            stations.append(station)
        }
    }
    
    func hasStation(stationName:String) -> Bool {
        return stations.contains(where: { $0.getName() == stationName })
    }
    
    func addConnection(station1Name:String, station2Name:String, lineName:String){
        if(self.hasStation(stationName: station1Name) &&
           self.hasStation(stationName: station2Name)){
            let station1:Station = Station(name: station1Name)
            let station2:Station = Station(name: station2Name)
            let connection1:Connection = Connection(station1: station1, station2: station2, linename: lineName)
            connections.append(connection1)
            let connection2:Connection = Connection(station1: station2, station2: station1, linename: lineName)
            connections.append(connection2)
        } else {
            
        }
    }
    
    func listPrint() -> String {
        var result = ""
        for item in stations{
            result += item.getName() + "\n"
            
        }
        return result
    }
}
