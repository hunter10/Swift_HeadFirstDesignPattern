//
//  main.swift
//  SubwayManager
//
//  Created by junginsung on 2017. 1. 2..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class LoadTester{
    var loader:SubwayLoader = SubwayLoader()
    var objectville:Subway = Subway()
    
    init(){
      
    }

    func Step1(){
        objectville = loader.loadFromFile(subwayFile: "ObjectVillSubway.txt")
        print("Testing statioins...\n")
        
        print(objectville.listPrint())
        
        
//        if(objectville.hasStation(stationName: "DRY Drive"))
//        {
//            print("...station test passed successfully. \n")
//        }
//        else{
//            print("...staion test FAILED.\n")
//        }
        
    }
    
    
}


let tester:LoadTester = LoadTester()
tester.Step1()

//let loader:SubwayLoader = SubwayLoader()
//loader.loadFromFile(subwayFile: "ObjectVillSubway.txt")


