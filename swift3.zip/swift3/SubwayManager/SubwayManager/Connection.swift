//
//  Connection.swift
//  SubwayManager
//
//  Created by junginsung on 2017. 1. 2..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation
public class Connection{
    var st1 = Station(name: "")
    var st2 = Station(name: "")
    var linename:String = ""
    
    init(station1:Station, station2:Station, linename:String){
        self.st1 = station1
        self.st2 = station2
        self.linename = linename
    }
    
    func getStation1() -> Station {
        return st1
    }
    
    func getStation2() -> Station {
        return st2
    }
    
    func getLineName()->String{
        return linename
    }
}
