//
//  Station.swift
//  SubwayManager
//
//  Created by junginsung on 2017. 1. 2..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

public class Station{
    var name:String = ""
    
    init(name:String){
        self.name = name
    }
    
    func getName() -> String {
        return self.name
    }
    
    // 자바의 오버라이드 버전임 고쳐야 함
    func  equals(obj:AnyObject) -> Bool {
        let otherStation:Station = obj as! Station
        if(otherStation.getName() == self.name){
            return true
        }
        
        return false
    }
    
    // 자바의 오버라이드 버전임 고쳐야 함
    func hashCode()->Int{
        return self.name.lowercased().hashValue
    }
}
