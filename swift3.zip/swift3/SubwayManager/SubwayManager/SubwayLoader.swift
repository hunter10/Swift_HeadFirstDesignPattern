//
//  SubwayLoader.swift
//  SubwayManager
//
//  Created by junginsung on 2017. 1. 8..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class SubwayLoader
{
    var subway:Subway
    
    init()
    {
        subway = Subway()
    }
    
    
    func loadFromFile(subwayFile:String) -> Subway {
        
        var result = ""
        
        let file = "ObjectVilleSubway.txt"
        
        
        if let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first{
            let path = dir.appendingPathComponent(file)
            
            //reading
            do{
                result = try String(contentsOf: path, encoding: String.Encoding.utf8)
            }
            catch{
                
            }
        }
        
        loadStation(subway: subway, reader: result)
        
        
        
        return subway
    }
    
    func loadStation(subway:Subway, reader:String) {
        let currentLine = reader.components(separatedBy: "\n")
        
        for stationName in currentLine
        {
            if(stationName == "")
            {
                return
            }
            
            subway.addStation(stationName: stationName)
        }
        
        //print(subway.listPrint())
    }
    
    func  loadLine(subway:Subway, totalfile:String, lineName:String) {
        //station1Name:String = ""
        //station2Name:String = ""
        
    }
    
    
    


}
