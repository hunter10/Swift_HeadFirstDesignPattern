//
//  RemoteControl.swift
//  RemoteControlManager
//
//  Created by junginsung on 2017. 2. 12..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

protocol Command{
    func execute()
    func undo()
}

class CommandElement: Command {
    func execute(){
    }
    
    func undo() {
    }
}


class RemoteControl{
    var onCommands:[CommandElement] = [CommandElement](repeating: CommandElement(), count: 7)
    var offCommands:[CommandElement] = [CommandElement](repeating: CommandElement(), count: 7)
    var undoCommand = CommandElement()
    
    init(){
        //let noCommnad:CommandElement = CommandElement()
        //for i in 0...7 {
        //    onCommands[i] = noCommnad
        //    offCommands[i] = noCommnad
        //}
    }
    
    func setCommand(slot:Int, onCommand:CommandElement, offCommand:CommandElement){
        onCommands[slot] = onCommand
        offCommands[slot] = offCommand
    }
    
    func onButtonWasPushed(slot:Int){
        onCommands[slot].execute()
        undoCommand = onCommands[slot]
    }
    
    func offButtonWasPushed(slot:Int){
        offCommands[slot].execute()
        undoCommand = offCommands[slot]
    }
    
    func undoButtonWasPushed(){
        undoCommand.undo()
    }
    
    func toString()->String{
        var result:String = ""
        
        result.append("\n --- Remote Control --- \n")
        for i in 0..<onCommands.count {
            result.append("[slot \(i)] \(String(describing: type(of: onCommands[i])))\n")
            
        }
        
        return result
    }
}
