//
//  Stereo.swift
//  RemoteControlManager
//
//  Created by junginsung on 2017. 2. 12..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class Stereo : CommandElement{
    var volume:Int = 0
    
    func on(){
        print("Stereo On")
    }
    
    func off(){
        print("Stereo Off")
    }
    
    func setCd(){
        print("Stereo Set CD")
    }
    
    func setDvd(){
        print("Stereo Set DVD")
    }
    
    func setRadio(){
        print("Stereo Set Radio")
    }
    
    func setVolume(volume:Int){
        self.volume = volume
        print("Stereo Set Volume \(volume)")
    }
}

class StereoOnWithCDCommand : CommandElement{
    var stereo:Stereo
    
    init(stereo:Stereo){
        self.stereo = stereo
    }
    
    override func execute() {
        stereo.on()
        stereo.setCd()
        stereo.setVolume(volume: 11)
    }
    
    override func undo() {
        stereo.off()
    }
}

class StereoOffCommand : CommandElement{
    var stereo:Stereo
    
    init(stereo:Stereo){
        self.stereo = stereo
    }
    
    override func execute() {
        stereo.off()
    }
    
    override func undo() {
        stereo.on()
        stereo.setCd()
        stereo.setVolume(volume: 11)
    }
}
