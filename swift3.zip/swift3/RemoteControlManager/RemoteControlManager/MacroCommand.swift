//
//  MacroCommand.swift
//  RemoteControlManager
//
//  Created by junginsung on 2017. 2. 12..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class MacroCommand : CommandElement{
    var commands:[CommandElement] = []
    
    init(commands:[CommandElement]){
        self.commands = commands
    }
    
    override func execute() {
        for i in 0..<commands.count{
            commands[i].execute()
        }
    }
}
