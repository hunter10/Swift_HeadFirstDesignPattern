//
//  CeilingFan.swift
//  RemoteControlManager
//
//  Created by junginsung on 2017. 2. 12..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class CeilingFan{
    var name:String = ""
    static let HIGH:Int = 3
    static let MEDIUM:Int = 2
    static let LOW:Int = 1
    static let OFF:Int = 0
    var speed:Int = 0
    
    init(name:String){
        self.name = name
        speed = CeilingFan.OFF
    }
    
    func high(){
        speed = CeilingFan.HIGH
        print("\(name) Fan is High")
    }
    
    func medium(){
        speed = CeilingFan.MEDIUM
        print("\(name) Fan is Medium")
    }
    
    func low(){
        speed = CeilingFan.LOW
        print("\(name) Fan is Low")
    }
    
    func on(){
        print("\(name) Fan is On")
    }
    
    func off(){
        speed = CeilingFan.OFF
        print("\(name) Fan is Off")
    }
    
    func getSpeed()->Int{
        return speed
    }
}

class CeilingFanHighCommand:CommandElement{
    var ceilingFan:CeilingFan?
    var prevSpeed:Int = 0
    
    init(ceilingFan:CeilingFan){
        self.ceilingFan = ceilingFan
    }
    
    override func execute() {
        prevSpeed = (ceilingFan?.getSpeed())!
        ceilingFan?.high()
    }
    
    override func undo() {
        if(prevSpeed == CeilingFan.HIGH){
            ceilingFan?.high()
        }
        else if(prevSpeed == CeilingFan.MEDIUM){
            ceilingFan?.medium()
        }
        else if(prevSpeed == CeilingFan.LOW){
            ceilingFan?.low()
        }
        else if(prevSpeed == CeilingFan.OFF){
            ceilingFan?.off()
        }
    }

}

class CeilingFanMediumCommand:CommandElement{
    var ceilingFan:CeilingFan?
    var prevSpeed:Int = 0
    
    init(ceilingFan:CeilingFan){
        self.ceilingFan = ceilingFan
    }
    
    override func execute() {
        prevSpeed = (ceilingFan?.getSpeed())!
        ceilingFan?.medium()
    }
    
    override func undo() {
        if(prevSpeed == CeilingFan.HIGH){
            ceilingFan?.high()
        }
        else if(prevSpeed == CeilingFan.MEDIUM){
            ceilingFan?.medium()
        }
        else if(prevSpeed == CeilingFan.LOW){
            ceilingFan?.low()
        }
        else if(prevSpeed == CeilingFan.OFF){
            ceilingFan?.off()
        }
    }
    
}

class CeilingFanLowCommand:CommandElement{
    var ceilingFan:CeilingFan?
    var prevSpeed:Int = 0
    
    init(ceilingFan:CeilingFan){
        self.ceilingFan = ceilingFan
    }
    
    override func execute() {
        prevSpeed = (ceilingFan?.getSpeed())!
        ceilingFan?.low()
    }
    
    override func undo() {
        if(prevSpeed == CeilingFan.HIGH){
            ceilingFan?.high()
        }
        else if(prevSpeed == CeilingFan.MEDIUM){
            ceilingFan?.medium()
        }
        else if(prevSpeed == CeilingFan.LOW){
            ceilingFan?.low()
        }
        else if(prevSpeed == CeilingFan.OFF){
            ceilingFan?.off()
        }
    }
    
}

class CeilingFanOffCommand:CommandElement{
    var ceilingFan:CeilingFan?
    var prevSpeed:Int = 0
    
    init(ceilingFan:CeilingFan){
        self.ceilingFan = ceilingFan
    }
    
    override func execute() {
        prevSpeed = (ceilingFan?.getSpeed())!
        ceilingFan?.off()
    }
    
    override func undo() {
        if(prevSpeed == CeilingFan.HIGH){
            ceilingFan?.high()
        }
        else if(prevSpeed == CeilingFan.MEDIUM){
            ceilingFan?.medium()
        }
        else if(prevSpeed == CeilingFan.LOW){
            ceilingFan?.low()
        }
        else if(prevSpeed == CeilingFan.OFF){
            ceilingFan?.off()
        }
    }
    
}



class CeilingFanOnCommand : CommandElement{
    var ceilingFan:CeilingFan?
    
    init(ceilingFan:CeilingFan){
        self.ceilingFan = ceilingFan
    }
    
    override func execute() {
        ceilingFan?.on()
    }
    
    override func undo() {
        ceilingFan?.off()
    }
}

/*
class CeilingFanOffCommand : CommandElement{
    var ceilingFan:CeilingFan?
    
    init(ceilingFan:CeilingFan){
        self.ceilingFan = ceilingFan
    }
    
    override func execute() {
        ceilingFan?.off()
    }
    
    override func undo() {
        ceilingFan?.on()
    }
}
*/
