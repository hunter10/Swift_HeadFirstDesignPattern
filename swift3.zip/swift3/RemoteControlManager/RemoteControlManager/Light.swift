//
//  Light.swift
//  RemoteControlManager
//
//  Created by junginsung on 2017. 2. 12..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class Light{
    var name:String = ""
    
    init(name:String){
        self.name = name
    }
    
    func on(){
        print("\(name) Light is On")
    }
    
    func off(){
        print("\(name) Light is Off")
    }
}

class LightOnCommand : CommandElement{
    var light:Light?
    
    init(light:Light){
        self.light = light
    }
    
    override func execute() {
        light?.on()
    }
    
    override func undo() {
        light?.off()
    }
}

class LightOffCommand : CommandElement{
    var light:Light?
    
    init(light:Light){
        self.light = light
    }
    
    override func execute() {
        light?.off()
    }
    
    override func undo() {
        light?.on()
    }
}
