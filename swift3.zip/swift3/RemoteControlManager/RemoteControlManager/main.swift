//
//  main.swift
//  RemoteControlManager
//
//  Created by junginsung on 2017. 2. 12..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

print("Hello, World!")

var remote:RemoteControl = RemoteControl()

var livingRoomLight:Light = Light(name:"Living Room")
var livingRoomLightOn:LightOnCommand = LightOnCommand(light: livingRoomLight)
var livingRoomLightOff:LightOffCommand = LightOffCommand(light : livingRoomLight)

var kitchenLight:Light = Light(name:"Kitchen Room")
var kitchenRoomLightOn:LightOnCommand = LightOnCommand(light: kitchenLight)
var kitchenRoomLightOff:LightOffCommand = LightOffCommand(light : kitchenLight)

var partyOn:[CommandElement] = [livingRoomLightOn, kitchenRoomLightOn]
var partyOff:[CommandElement] = [livingRoomLightOff, kitchenRoomLightOff]

var partyOnMacro:MacroCommand = MacroCommand(commands: partyOn)
var partyOffMacro:MacroCommand = MacroCommand(commands: partyOff)

remote.setCommand(slot: 0, onCommand: partyOnMacro, offCommand: partyOffMacro)
remote.onButtonWasPushed(slot: 0)
print("---")
remote.offButtonWasPushed(slot: 0)


/*
var ceilingFan1:CeilingFan = CeilingFan(name: "Living Room")
var ceilingFanHighCommand:CeilingFanHighCommand = CeilingFanHighCommand(ceilingFan: ceilingFan1)
var ceilingFanMediumCommand:CeilingFanMediumCommand = CeilingFanMediumCommand(ceilingFan: ceilingFan1)
var ceilingFanLowCommand:CeilingFanLowCommand = CeilingFanLowCommand(ceilingFan: ceilingFan1)
var ceilingFanOffCommand:CeilingFanOffCommand = CeilingFanOffCommand(ceilingFan: ceilingFan1)

remote.setCommand(slot: 0, onCommand: ceilingFanHighCommand, offCommand: ceilingFanOffCommand)
remote.setCommand(slot: 1, onCommand: ceilingFanMediumCommand, offCommand: ceilingFanOffCommand)
remote.setCommand(slot: 2, onCommand: ceilingFanLowCommand, offCommand: ceilingFanOffCommand)

remote.onButtonWasPushed(slot: 0)
remote.offButtonWasPushed(slot: 0)
remote.undoButtonWasPushed()

remote.onButtonWasPushed(slot: 1)
//remote.offButtonWasPushed(slot: 1)
remote.undoButtonWasPushed()
*/

/*
var livingRoomLight:Light = Light(name:"Living Room")
var livingRoomLightOn:LightOnCommand = LightOnCommand(light: livingRoomLight)
var livingRoomLightOff:LightOffCommand = LightOffCommand(light : livingRoomLight)

var kitchenLight:Light = Light(name:"Kitchen Room")
var kitchenRoomLightOn:LightOnCommand = LightOnCommand(light: kitchenLight)
var kitchenRoomLightOff:LightOffCommand = LightOffCommand(light : kitchenLight)

var ceilingFan1:CeilingFan = CeilingFan(name: "Living Room")
var ceilingFan1On:CeilingFanOnCommand = CeilingFanOnCommand(ceilingFan:ceilingFan1)
var ceilingFan1Off:CeilingFanOffCommand = CeilingFanOffCommand(ceilingFan:ceilingFan1)

var garageDoor:GarageDoor = GarageDoor()
var garageDoorUpCommand:GarageDoorUpCommand = GarageDoorUpCommand(garageDoor: garageDoor)
var garageDoorDownCommand:GarageDoorDownCommand = GarageDoorDownCommand(garageDoor: garageDoor)

var stereo:Stereo = Stereo()
var stereoOnWithCD:StereoOnWithCDCommand = StereoOnWithCDCommand(stereo:stereo)
var stereoOff:StereoOffCommand = StereoOffCommand(stereo:stereo)



remote.setCommand(slot: 0, onCommand: livingRoomLightOn, offCommand: livingRoomLightOff)
remote.setCommand(slot: 1, onCommand: kitchenRoomLightOn, offCommand: kitchenRoomLightOff)
remote.setCommand(slot: 2, onCommand: ceilingFan1On, offCommand: ceilingFan1Off)
remote.setCommand(slot: 3, onCommand: garageDoorUpCommand, offCommand: garageDoorDownCommand)
remote.setCommand(slot: 4, onCommand: stereoOnWithCD, offCommand: stereoOff)

print(remote.toString())

remote.onButtonWasPushed(slot: 0)
remote.offButtonWasPushed(slot: 0)
remote.undoButtonWasPushed()

remote.onButtonWasPushed(slot: 1)
remote.offButtonWasPushed(slot: 1)
remote.undoButtonWasPushed()
*/

/*
remote.onButtonWasPushed(slot: 2)
remote.offButtonWasPushed(slot: 2)

remote.onButtonWasPushed(slot: 3)
remote.offButtonWasPushed(slot: 3)

remote.onButtonWasPushed(slot: 4)
remote.offButtonWasPushed(slot: 4)
 */
