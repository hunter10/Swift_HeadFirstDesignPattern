//
//  GarageDoor.swift
//  RemoteControlManager
//
//  Created by junginsung on 2017. 2. 12..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class GarageDoor{
    func up(){
        print("GarageDoor is Open")
    }
    
    func down(){
        print("GarageDoor is Close")
    }
    
    func stop(){
        print("GarageDoor is Stop")
    }
    
    func lightOn(){
        print("GarageDoor is LightOn")
    }
    
    func lightOff(){
        print("GarageDoor is LightOff")
    }
}

class GarageDoorUpCommand:CommandElement{
    var garageDoor:GarageDoor?
    
    init(garageDoor:GarageDoor){
        self.garageDoor = garageDoor
    }
    
    override func execute() {
        garageDoor?.up()
    }
    
    override func undo() {
        garageDoor?.down()
    }
}

class GarageDoorDownCommand:CommandElement{
    var garageDoor:GarageDoor?
    
    init(garageDoor:GarageDoor){
        self.garageDoor = garageDoor
    }
    
    override func execute() {
        garageDoor?.down()
    }
    
    override func undo(){
        garageDoor?.up()
    }
}
