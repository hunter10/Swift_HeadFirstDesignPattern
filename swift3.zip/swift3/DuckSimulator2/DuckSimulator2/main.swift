//
//  main.swift
//  DuckSimulator2
//
//  Created by junginsung on 2017. 2. 17..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

print("Hello, World!")

class MallardDuck : Duck{
    func quack(){
        print("Quack")
    }
    
    func fly(){
        print("I'm flying")
    }
}

class WildTurkey : Turkey{
    func gobble(){
        print("Gobble gobble")
    }
    
    func fly(){
        print("I'm flying a short distance")
    }
}

func testDuck(duck:Duck){
    duck.quack()
    duck.fly()
}

var duck:MallardDuck = MallardDuck()
var turkey:WildTurkey = WildTurkey()
var turkeyAdapter:Duck = TurkeyAdapter(turkey: turkey)

print("turkey say ---")
turkey.gobble()
turkey.fly()

print("duck say ---")
testDuck(duck: duck)

print("turkey adapter say ---")
testDuck(duck: turkeyAdapter)
