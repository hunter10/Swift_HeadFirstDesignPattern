//
//  Duck.swift
//  DuckSimulator2
//
//  Created by junginsung on 2017. 2. 17..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

protocol Duck {
    func quack()
    func fly()
}

protocol Turkey {
    func gobble()
    func fly()
}

class TurkeyAdapter : Duck{
    var turkey:Turkey?
    
    init(turkey:Turkey){
        self.turkey = turkey
    }
    
    func quack() {
        turkey?.gobble()
    }
    
    func fly(){
        for _ in 0...5 {
            turkey?.fly()
        }
    }
}
