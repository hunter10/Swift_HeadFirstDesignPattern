//
//  main.swift
//  RestaurantManager
//
//  Created by junginsung on 2017. 2. 19..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

/*
print("Hello, World!")

var pancakeHouseMenu = PancakeHouseMenu()
//var breakfastItems = pancakeHouseMenu.getMenuItems()
//var breakfastItems = pancakeHouseMenu.createIterator()

var dinerMenu = DinerMenu()
//var lunchItems = dinerMenu.getMenuItems()
//var lunchItems = dinerMenu.createIterator()

var cafeMenu = CafeMenu()
*/
/*
for item in breakfastItems {
    var name = (item as! MenuItem).getName()
    var price = (item as! MenuItem).getPrice()
    var description = (item as! MenuItem).getDescription()
    
    print("\(name) \(price) \(description)")
}
*/
//print("---")
/*
for item in lunchItems {
    var name = item.getName()
    var price = item.getPrice()
    var description = item.getDescription()
    
    print("\(name) \(price) \(description)")
}
*/

//var waitress = Waitress(PanCakeHouseMenu: pancakeHouseMenu, DinerMenu: dinerMenu, CafeMenu: cafeMenu)
//waitress.PrintMenu()


var pancakeHouseMenu = Menu(name: "팬케이크 하우스 메뉴", description: "아침 메뉴")
var dinerMenu = Menu(name: "객체마을 식당 메뉴", description: "점심 메뉴")
var cafeMenu = Menu(name: "카페 메뉴", description: "저녁 메뉴")
var dessertMenu = Menu(name: "디저트 메뉴", description: "디저트를 즐겨 보세요!")

var allMenus = Menu(name: "전체메뉴", description: "전체메뉴")

allMenus.add(menucomponent: pancakeHouseMenu)
allMenus.add(menucomponent: dinerMenu)
allMenus.add(menucomponent: cafeMenu)

allMenus.add(menucomponent: dessertMenu)

pancakeHouseMenu.add(menucomponent: MenuItem(name: "K&B 팬케이크 세트",
                                             description: "스크램블드 에그와 토스트가 곁들여진 팬케이크",
                                             vegetarian: true,
                                             price: 2.99))
pancakeHouseMenu.add(menucomponent: MenuItem(name: "레귤러 팬케이크 세트",
                                             description: "달걀 후라이와 소시지가 곁들여진 팬케이크",
                                             vegetarian: false,
                                             price: 2.99))
pancakeHouseMenu.add(menucomponent: MenuItem(name: "블루베리 팬케이크",
                                             description: "신선한 블루베리와 블루베리 시럽으로 만든 팬케이크",
                                             vegetarian: true,
                                             price: 3.49))
pancakeHouseMenu.add(menucomponent: MenuItem(name: "와플",
                                             description: "와플, 취향에 따라 블루베리나 딸기를 얹을수 있습니다.",
                                             vegetarian: true,
                                             price: 3.59))



dinerMenu.add(menucomponent: MenuItem(name: "채식주의자용 BLT",
                                      description: "통밀 위에(식물성)베이컨, 상추, 토마토를 얹은 메뉴",
                                      vegetarian: true,
                                      price: 2.99))
dinerMenu.add(menucomponent: MenuItem(name: "BLT",
                                      description: "통밀 위에 베이컨, 상추, 토마토를 얹은 메뉴",
                                      vegetarian: false,
                                      price: 2.99))
dinerMenu.add(menucomponent: MenuItem(name: "오늘의 스프",
                                      description: "감자 샐러드를 곁들인 오늘의 스프",
                                      vegetarian: false,
                                      price: 3.29))
dinerMenu.add(menucomponent: MenuItem(name: "핫도그",
                                      description: "사워크라우트, 갖은양념, 양파, 치즈가 곁들여진 핫도그",
                                      vegetarian: false,
                                      price: 3.05))
dinerMenu.add(menucomponent: MenuItem(name: "파스타",
                                      description: "마리나라 소스 스파게티. 효모빵도 드립니다.",
                                      vegetarian: true,
                                      price: 3.89))


cafeMenu.add(menucomponent: MenuItem(name: "베지 버거와 에어 프라이",
                                     description: "통밀빵, 상추, 토마토, 감자튀김이 첨가된 베지 버거",
                                     vegetarian: true,
                                     price: 3.99))
cafeMenu.add(menucomponent: MenuItem(name: "오늘의 스프",
                                     description: "샐러드가 곁들여진 오늘의 스프",
                                     vegetarian: false,
                                     price: 3.69))
cafeMenu.add(menucomponent: MenuItem(name: "베리또",
                                     description: "통 핀토콩과 살사, 구아카몰이 곁들여진 푸짐한 베리또",
                                     vegetarian: true,
                                     price: 4.29))

dessertMenu.add(menucomponent: MenuItem(name: "애플 파이",
                                        description: "바삭바삭한 크러스트에 바닐라 아이스크림이 얹혀있는 애플파이",
                                        vegetarian: true,
                                        price: 1.59))



var waitress = Waitress(allMenus: allMenus)
//waitress.printMenu()
waitress.printVegetarianMenu()
