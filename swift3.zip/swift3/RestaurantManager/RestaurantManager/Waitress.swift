//
//  Waitress.swift
//  RestaurantManager
//
//  Created by junginsung on 2017. 2. 19..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class Waitress{
    var allMenus:MenuComponent? = nil
    
    init(allMenus:MenuComponent){
        self.allMenus = allMenus
    }
    
    func printMenu(){
        allMenus?.DoPrint()
    }
    
    func printVegetarianMenu(){
        print("채식주의자를 위한 메뉴")
        for item in (allMenus as! Menu).getMenuItems()! {
            //print((item as! Menu).getName())
            
            for subitem in (item as! Menu).getMenuItems()!{
                //print((subitem as! MenuItem).getName())
                
                let menuItem = (subitem as! MenuItem)
                if(menuItem.isVegetarian() )
                {
                    menuItem.DoPrint()
                }
            }
        }
        
        //for item in allMenus{
        //    if(item?.isVegetarian()){
        //
        //    }
        //}
    }
}

/*
class Waitress {
    //var pancakeHouseMenu:PancakeHouseMenu?
    //var dinerMenu:DinerMenu?
    
    var pancakeHouseMenu:Menu?
    var dinerMenu:Menu?
    var cafeMenu:Menu?
    
    init(PanCakeHouseMenu:Menu, DinerMenu:Menu, CafeMenu:Menu)
    {
        self.pancakeHouseMenu = PanCakeHouseMenu
        self.dinerMenu = DinerMenu
        self.cafeMenu = CafeMenu
    }
    
    func PrintMenu(){
        //let pancakeIterator = pancakeHouseMenu?.createIterator()
        //let dinerIterator = dinerMenu?.createIterator()
        //let cafeIterator = cafeMenu?.createIterator()

        // 수동 이터레이터
        //print("메뉴\n --- \n아침메뉴")
        //printMenu(iterator: pancakeIterator!)
        //print("\n점심메뉴")
        //printMenu(iterator: dinerIterator!)
        //print("\n저녁메뉴")
        //printMenu(iterator: cafeIterator!)
        
        // 컬렉션에 있는 이터레이터를 이용하기
        print("메뉴\n --- \n아침메뉴")
        printMenu(menuitems : (pancakeHouseMenu?.getMenuItems())!)
        print("\n점심메뉴")
        printMenu(menuitems : (dinerMenu?.getMenuItems())!)
        print("\n저녁메뉴")
        printMenu(menuitems : (cafeMenu?.getMenuItems())!)
    }
    
    func printMenu(menuitems : [AnyObject])
    {
        for tempitem in menuitems{
            let item = tempitem as! MenuItem
            
            let name = item.getName()
            let price = item.getPrice()
            let description = item.getDescription()
            
            print("\(name) \(price) -- \(description)")
        }
    }
    
    func printMenu(iterator:Iterator)
    {
        while iterator.hasNext() {
            let item = iterator.next() as! MenuItem
            
            let name = item.getName()
            let price = item.getPrice()
            let description = item.getDescription()
            
            print("\(name) \(price) -- \(description)")
        }
    }
}
 */
