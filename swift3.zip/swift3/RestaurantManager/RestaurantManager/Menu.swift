//
//  Menu.swift
//  RestaurantManager
//
//  Created by junginsung on 2017. 2. 19..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

class Menu : MenuComponent{
    
    var menuComponents:[MenuComponent] = []
    var name = ""
    var description = ""
    
    init(name:String, description:String){
        self.name = name
        self.description = description
    }
    
    func getMenuItems()->[AnyObject]?
    {
        return menuComponents
    }
    
    override func add(menucomponent:MenuComponent){
        menuComponents.append(menucomponent)
    }
    
    override func remove(menucomponent:MenuComponent){
        let index = menuComponents.index{$0 === menucomponent}
        menuComponents.remove(at: index!)
        
    }
    
    override func getChild(i:Int) -> MenuComponent?{
        return menuComponents[i]
    }
    
    override func getName() -> String{
        return name
    }
    
    override func getDescription() -> String{
        return description
    }
    
    /*
    override func getPrice() -> Double{
        return 0
    }
    
    override func isVegetarian() -> Bool{
        return false
    }
    */
    
    override func DoPrint(){
        let name = getName()
        let desc = getDescription()
        print("\n \(name) \(desc)")
        print("-----------")
        
        for item in menuComponents{
            item.DoPrint()
        }
    }

}

class MenuItem : MenuComponent{
    var name:String = ""
    var description:String = ""
    var vegetarian:Bool = false
    var price:Double = 0
    
    init(name:String, description:String, vegetarian:Bool, price:Double){
        self.name = name
        self.description = description
        self.vegetarian = vegetarian
        self.price = price
    }
    
    override func getName()->String{
        return name
    }
    
    override func getDescription()->String{
        return description
    }
    
    override func getPrice()->Double{
        return price
    }
    
    override func isVegetarian()->Bool{
        return vegetarian
    }

    override func DoPrint() {
        let name = getName()
        var vege = ""
        if(isVegetarian()){
            vege = "(v)"
        }
        
        let price = getPrice()
        let desc = getDescription()
        
        print("    \(name) \(vege), \(price) -- \(desc)")
    }
}

class MenuComponent{
    func add(menucomponent:MenuComponent){
    }
    
    func remove(menucomponent:MenuComponent){
    }
    
    func getChild(i:Int) -> MenuComponent?{
        return nil
    }
    
    func getName() -> String{
        return ""
    }
    
    func getDescription() -> String{
        return ""
    }
    
    func getPrice() -> Double{
        return 0
    }
    
    func isVegetarian() -> Bool{
        return false
    }
    
    func DoPrint(){
        
    }
}

// ArrayList를 구현했다 쳐야 하니까
class PancakeHouseMenu : Menu {
    var menuItems:[AnyObject] = []
    
    override init(name:String, description:String){
        super.init(name:name, description: description)
        
        addItem(name: "K&B 팬케이크 세트",
                description: "스크램블드 에그와 토스트가 곁들여진 팬케이크",
                vegetarian: true,
                price: 2.99)
        
        addItem(name: "레귤러 팬케이크 세트",
                description: "달걀 후라이와 소시지가 곁들여진 팬케이크",
                vegetarian: false,
                price: 2.99)
        
        addItem(name: "블루베리 팬케이크",
                description: "신선한 블루베리와 블루베리 시럽으로 만든 팬케이크",
                vegetarian: true,
                price: 3.49)
        
        addItem(name: "와플",
                description: "와플, 취향에 따라 블루베리나 딸기를 얹을수 있습니다.",
                vegetarian: true,
                price: 3.59)
    }
    
    func addItem(name:String, description:String, vegetarian:Bool, price:Double) {
        let menuItem = MenuItem(name: name, description: description, vegetarian: vegetarian, price: price)
        menuItems.append(menuItem)
    }
    
    override func getMenuItems()->[AnyObject]{
        return menuItems
    }
    
    //func createIterator() -> Iterator{
        //return PancakeHouseMenuterator(items: menuItems as! [MenuItem])
        //return NormalIterator<MenuItem>(items: menuItems as! [MenuItem])
    //}

}

class DinerMenu : Menu {
    var numberOfItems:Int = 0
    var menuItems:[MenuItem?] = [nil, nil, nil, nil]
    
    override init(name:String, description:String){
        super.init(name:name, description: description)
        
        addItem(name: "채식주의자용 BLT",
                description: "통밀 위에(식물성)베이컨, 상추, 토마토를 얹은 메뉴",
                vegetarian: true,
                price: 2.99)
        
        addItem(name: "BLT",
                description: "통밀 위에 베이컨, 상추, 토마토를 얹은 메뉴",
                vegetarian: false,
                price: 2.99)
        
        addItem(name: "오늘의 스프",
                description: "감자 샐러드를 곁들인 오늘의 스프",
                vegetarian: false,
                price: 3.29)
        
        addItem(name: "핫도그",
                description: "사워크라우트, 갖은양념, 양파, 치즈가 곁들여진 핫도그",
                vegetarian: false,
                price: 3.05)
    }
    
    func addItem(name:String, description:String, vegetarian:Bool, price:Double) {
        let menuItem = MenuItem(name: name, description: description, vegetarian: vegetarian, price: price)
        //menuItems.append(menuItem)
        menuItems[numberOfItems] = menuItem
        numberOfItems = numberOfItems + 1
    }
    
    override func getMenuItems()->[AnyObject]{
        return menuItems as [AnyObject]
    }
    
    //func getMenuItems()->[MenuItem]{
    //    return menuItems as! [MenuItem]
    //}
    
    //func createIterator() -> Iterator{
        //return DinerMenuIterator(items: menuItems as! [MenuItem])
        //return NormalIterator<MenuItem>(items: menuItems as! [MenuItem])
   // }
}

class CafeMenu : Menu {
    var menuItems:[AnyObject] = []
    
    override init(name:String, description:String){
        super.init(name:name, description: description)
        
        addItem(name: "베지 버거와 에어 프라이",
                description: "통밀빵, 상추, 토마토, 감자튀김이 첨가된 베지 버거",
                vegetarian: true,
                price: 3.99)
        
        addItem(name: "오늘의 스프",
                description: "샐러드가 곁들여진 오늘의 스프",
                vegetarian: false,
                price: 3.69)
        
        addItem(name: "베리또",
                description: "통 핀토콩과 살사, 구아카몰이 곁들여진 푸짐한 베리또",
                vegetarian: true,
                price: 4.29)
    }
    
    func addItem(name:String, description:String, vegetarian:Bool, price:Double) {
        let menuItem = MenuItem(name: name, description: description, vegetarian: vegetarian, price: price)
        menuItems.append(menuItem)
        //menuItems[numberOfItems] = menuItem
        //numberOfItems = numberOfItems + 1
    }
    
    override func getMenuItems()->[AnyObject]{
        return menuItems
    }
    
    //func createIterator() -> Iterator{
        //return DinerMenuIterator(items: menuItems as! [MenuItem])
    //    return NormalIterator<MenuItem>(items: menuItems as! [MenuItem])
    //}
}
