//
//  Iterator.swift
//  RestaurantManager
//
//  Created by junginsung on 2017. 2. 19..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

// 외부 이터레이터 구현
protocol Iterator {
    func hasNext() -> Bool
    func next() -> AnyObject
}

//protocol Menu {
    //func createIterator() -> Iterator
//}

class NormalIterator<T> : Iterator {
    var items:[T] = []
    var position:Int = 0
    
    init(items:[T]){
        self.items = items
    }
    
    func next() -> AnyObject {
        let tempItem:T = items[position]
        position = position + 1
        return tempItem as AnyObject
    }
    
    func hasNext() -> Bool {
        if(position >= items.count){
            return false
        } else {
            return true
        }
    }
}


/*
class DinerMenuIterator : Iterator{
    var items:[MenuItem] = []
    var position:Int = 0
    
    init(items:[MenuItem]){
        self.items = items
    }
    
    func next() -> AnyObject {
        let menuItem:MenuItem = items[position]
        position = position + 1
        
        return menuItem as AnyObject
    }
    
    func hasNext() -> Bool {
        if( position >= items.count) { // || items[position] == nil ) {
            return false
        } else {
            return true
        }
        
    }
}

class PancakeHouseMenuterator : Iterator{
    var items:[MenuItem] = []
    var position:Int = 0
    
    init(items:[MenuItem]){
        self.items = items
    }
    
    func next() -> AnyObject {
        let menuItem:MenuItem = items[position]
        position = position + 1
        
        return menuItem as AnyObject
    }
    
    func hasNext() -> Bool {
        if( position >= items.count) { // || items[position] == nil ) {
            return false
        } else {
            return true
        }
        
    }
}
*/
