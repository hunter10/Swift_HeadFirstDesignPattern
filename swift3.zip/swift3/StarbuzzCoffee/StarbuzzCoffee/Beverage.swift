//
//  Beverage.swift
//  StarbuzzCoffee
//
//  Created by junginsung on 2017. 1. 22..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

protocol Beverage{
    var description:String{
        get
        set
    }
    
    func getDescription() -> String
    
    func cost() -> Double
}

// 이하 4개 CoCreateComponent에 해당
class Espresso : Beverage{
    internal var description: String
    init(){
        description = "에스프레소"
    }
    
    
    internal func getDescription() -> String{
        return description
    }
    
    internal func cost() -> Double {
        return 1.99
    }
}

class HouseBlend : Beverage{
    internal var description: String
    init(){
        description = "하우스 블렌드 커피"
    }
    
    internal func getDescription() -> String{
        return description
    }
    
    internal func cost() -> Double {
        return 0.89
    }
}

class DarkRoast : Beverage{
    internal var description: String
    init(){
        description = "다크로스트 커피"
    }
    
    internal func getDescription() -> String{
        return description
    }
    
    internal func cost() -> Double {
        return 0.99
    }
}

class Decaf : Beverage{
    internal var description: String
    init(){
        description = "디카페인 커피"
    }
    
    internal func getDescription() -> String{
        return description
    }
    
    internal func cost() -> Double {
        return 1.05
    }
}
