//
//  main.swift
//  StarbuzzCoffee
//
//  Created by junginsung on 2017. 1. 22..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

print("Hello, World!")

// 이하 테스트 코드
var someCoffee : Beverage = Espresso()
print("Cost : \(someCoffee.cost()) \(someCoffee.getDescription())")

var someCoffee2 : Beverage = DarkRoast()
someCoffee2 = Mocha(beverage: someCoffee2)
someCoffee2 = Mocha(beverage: someCoffee2)
someCoffee2 = Whip(beverage: someCoffee2)
print("Cost : \(someCoffee2.cost()) \(someCoffee2.getDescription())")

var someCoffee3 : Beverage = HouseBlend()
someCoffee3 = Soy(beverage: someCoffee3)
someCoffee3 = Mocha(beverage: someCoffee3)
someCoffee3 = Whip(beverage: someCoffee3)
print("Cost : \(someCoffee3.cost()) \(someCoffee3.getDescription())")
