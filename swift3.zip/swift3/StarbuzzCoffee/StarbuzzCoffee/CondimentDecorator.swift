//
//  CondimentDecorator.swift
//  StarbuzzCoffee
//
//  Created by junginsung on 2017. 1. 22..
//  Copyright © 2017년 junginsung. All rights reserved.
//

import Foundation

// 이하 1개 데코레이터 Component에 해당
class CondimentDecorator : Beverage{
    private let beverage:Beverage
    
    internal var description: String
    required init(beverage:Beverage){
        description = "Condiment Decorator"
        self.beverage = beverage
    }
    
    internal func getDescription() -> String{
        return beverage.getDescription()
    }
    
    internal func cost() -> Double {
        return beverage.cost()
    }
}

// 이하 첨가물용 코드
class SteamMilk : CondimentDecorator{
    required init(beverage: Beverage){
        super.init(beverage:beverage)
    }
    
    override func getDescription() -> String {
        return super.getDescription() + ", 스팀밀크"
    }
    
    override func cost() -> Double {
        return 0.10 + super.cost()
    }
}

class Mocha : CondimentDecorator{
    required init(beverage: Beverage){
        super.init(beverage:beverage)
    }
    
    override func getDescription() -> String {
        return super.getDescription() + ", 모카"
    }
    
    override func cost() -> Double {
        return 0.20 + super.cost()
    }
}

class Soy : CondimentDecorator{
    required init(beverage: Beverage){
        super.init(beverage:beverage)
    }
    
    override func getDescription() -> String {
        return super.getDescription() + ", 두유"
    }
    
    override func cost() -> Double {
        return 0.15 + super.cost()
    }
}

class Whip : CondimentDecorator{
    required init(beverage: Beverage){
        super.init(beverage:beverage)
    }
    
    override func getDescription() -> String {
        return super.getDescription() + ", 휘핑크림"
    }
    
    override func cost() -> Double {
        return 0.10 + super.cost()
    }
}
