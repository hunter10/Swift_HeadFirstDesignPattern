//
//  Weapon.swift
//  BoardGame
//
//  Created by junginsung on 2016. 12. 24..
//  Copyright © 2016년 junginsung. All rights reserved.
//

import Foundation

class Weapon{
    
}
