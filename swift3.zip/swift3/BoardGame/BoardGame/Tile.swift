//
//  Tile.swift
//  BoardGame
//
//  Created by junginsung on 2016. 11. 20..
//  Copyright © 2016년 junginsung. All rights reserved.
//

import Foundation

class Tile{
    var units = [Unit]()
    
    init()
    {
        //values.append(".")
    }
    
    func addUnit(unit:Unit) {
        units.append(unit)
    }
    
    func removeUnit(unit:Unit){
        
        // 스위프트에서는 오브젝트만 가지고 삭제할수 없음
        // 오브젝트안에서 무엇과 비교할지 기준이 있어야 함.
        //units.removeFirst({$0 == unit})
    }
    
    func removeUnits() {
        units.removeAll()
    }
    
//    func getUnits()->[Tile]{
//        
//    }
}
