//
//  Board.swift
//  BoardGame
//
//  Created by junginsung on 2016. 11. 20..
//  Copyright © 2016년 junginsung. All rights reserved.
//

import Foundation

class Board{
    var width = 0
    var height = 0
    var tiles:[Tile]
    
    static let Empty = 0
    
    init(width:Int, height:Int){
        self.width = width;
        self.height = height;
        
        self.tiles = Array(repeating:Tile(), count: (width * height))
        
        //Initialize()
    }
    
    subscript(x:Int, y:Int)->Tile{
        get{
            return self.tiles[y * self.width + x]
        }
        
        set(value){
            self.tiles[y * self.width + x] = value
        }
    }
    
    
    
//    func Initialize() {
//        
//        var idx = 0
//        for y in 0..<self.height{
//            for x in 0..<self.width{
//                self[x, y] = Tile(values: ["\(idx)"])
//                idx+=1
//            }
//        }
//    }
    
    func getTile(x:Int, y:Int) -> Tile {
        return self[x-1, y-1]
    }
    
    func addUnit(runit:Unit, x:Int, y:Int){
        let tile:Tile = getTile(x: x, y: y)
        tile.addUnit(unit: runit)
    }
    
    func removeUnit(runit:Unit, rx:Int, ry:Int)
    {
        let tile:Tile = getTile(x: rx, y: ry)
        tile.removeUnit(unit: runit)
    }
    
    func removeUnits(rx:Int, ry:Int){
        let tile:Tile = getTile(x:rx, y:ry)
        tile.removeUnits()
    }
    
    func  getUnits(x:Int, y:Int){// -> [Tile] {
        //return getTile(x, y).getUnits()
        
    }
    
    /*
    func ShowPrint()->String{
        var result = ""
        
        for y in 0..<self.height{
            for x in 0..<self.width{
                let v:Tile = self[x, y]
                
                result += "["
                for val in v.values{
                    result += val + ","
                }
                result += "]"
            }
            
            result += "\n"
        }
        
        return result
    }
    */
    
}
