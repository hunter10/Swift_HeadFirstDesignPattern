//
//  Unit.swift
//  BoardGame
//
//  Created by junginsung on 2016. 12. 18..
//  Copyright © 2016년 junginsung. All rights reserved.
//

import Foundation

class Unit{
    
    var type:String = ""
    var id:Int = 0
    var name:String = ""
    var weapons = [Weapon]()
    var properties = [String:AnyObject]()
    
    init(id:Int)
    {
        self.id = id
    }
    
    func setType(type:String){
        self.type = type
    }
    
    func getType()->String{
        return type
    }
    
    func getID()->Int{
        return id
    }
    
    func setName(name:String){
        self.name = name
    }
    
    func getName()->String{
        return name
    }
    
    func addWeapon(weapon:Weapon){
        self.weapons.append(weapon)
    }
    
    func getWeapons()->[Weapon]{
        return weapons
    }
    
    func setProperty(key:String, value:AnyObject){
        properties[key] = value
    }
    
    func getProperty(key:String)->AnyObject{
        return properties[key]!
    }
}
