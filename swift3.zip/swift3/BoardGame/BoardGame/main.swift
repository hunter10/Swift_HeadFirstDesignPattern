//
//  main.swift
//  BoardGame
//
//  Created by junginsung on 2016. 11. 20..
//  Copyright © 2016년 junginsung. All rights reserved.
//

import Foundation

/*
var myboard = Board(width: 2, height: 2)
print(myboard.ShowPrint())

let revInfo:Tile = myboard.GetTile(x: 2, y: 2)
print(revInfo.values)

myboard.AddUnit(unit: Unit(), x: 1, y: 2)
//let revInfo1:Tile = myboard.GetBoard(x: 1, y: 2)
//print(revInfo1.values)
//
//print(myboard.ShowPrint())
*/

let tester:UnitTester = UnitTester()
let unit:Unit = Unit(id: 1000)

class test{
    var h:Int = 0
    
    init(hit:Int){
        self.h = hit
    }
}

tester.testType(unit:unit, type:"infantry", expectedOutputType:"infantry1")

let a:AnyObject? = test(hit: 25)
tester.testUnitSpecificProperty(unit: unit, propertyName: "hitPoints", inputValue: a!, expectedOutputValue: a!)
