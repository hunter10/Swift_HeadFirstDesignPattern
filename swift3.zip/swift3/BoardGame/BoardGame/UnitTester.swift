//
//  UnitTester.swift
//  BoardGame
//
//  Created by junginsung on 2016. 12. 24..
//  Copyright © 2016년 junginsung. All rights reserved.
//

import Foundation

class UnitTester{
    func testType(unit:Unit, type:String, expectedOutputType:String){
        print("\nTesting setting/getting the type property.")
        
        unit.setType(type: type)
        let outputType = unit.getType()
        if(expectedOutputType == outputType)
        {
            print("Test passed")
        }
        else{
            print("Test failed: " + outputType)
        }
    }
    
    func testUnitSpecificProperty(unit:Unit, propertyName:String, inputValue:AnyObject, expectedOutputValue:AnyObject){
        print("\nTesting setting/getting a unit-specific property.")
        unit.setProperty(key: propertyName, value: inputValue)
        let outputValue:AnyObject = unit.getProperty(key: propertyName)
        if(expectedOutputValue === outputValue)
        {
            print("Test passed")
        } else{
            print("Test failed " + String((inputValue as! test).h))
        }
    }
}
